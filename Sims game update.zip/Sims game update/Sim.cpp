#include "Sim.h"
#include "CommunityEvent.h"

Sim::Sim(const std::string& name, int age) : name(name), age(age) {}

void Sim::participate(CommunityEvent* event) {
    event->startEvent();
    // Add other participation logic here
}
