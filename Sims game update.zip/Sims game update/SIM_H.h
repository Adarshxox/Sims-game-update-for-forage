#ifndef SIM_H
#define SIM_H

#include <string>
#include <vector>

class CommunityEvent; // Forward declaration

class Sim {
public:
    Sim(const std::string& name, int age);

    void participate(CommunityEvent* event);

private:
    std::string name;
    int age;
    std::vector<std::string> skills;
    std::vector<std::string> hobbies;
};

#endif // SIM_H
