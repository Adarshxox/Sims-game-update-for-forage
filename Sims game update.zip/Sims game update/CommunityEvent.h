#ifndef COMMUNITY_EVENT_H
#define COMMUNITY_EVENT_H

#include <string>
#include <vector>

class Sim; // Forward declaration

class CommunityEvent {
public:
    CommunityEvent(const std::string& eventName, const std::string& date, const std::string& location);

    virtual void startEvent();
    virtual void endEvent();

protected:
    std::string eventName;
    std::string date;
    std::string location;
    std::vector<Sim*> participants;
};

class Festival : public CommunityEvent {
public:
    Festival(const std::string& eventName, const std::string& date, const std::string& location, const std::string& festivalType);

    void celebrate();

private:
    std::string festivalType;
};

class MarketDay : public Festival {
public:
    MarketDay(const std::string& eventName, const std::string& date, const std::string& location, const std::string& festivalType);

    void sellGoods();
};

class CulturalFestival : public Festival {
public:
    CulturalFestival(const std::string& eventName, const std::string& date, const std::string& location, const std::string& festivalType);

    void celebrateCulture();
};

#endif // COMMUNITY_EVENT_H
